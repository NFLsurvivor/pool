# NFL Survivor – 3 joueurs (Gabriel, Étienne, Benoit)

Site statique prêt pour **GitHub Pages**.

## Déploiement rapide (GitHub Pages)

1. Créez un dépôt sur GitHub, par ex.: `nfl-survivor`.
2. Uploadez le fichier `index.html` (celui de ce dossier) à la racine du dépôt.
3. Dans **Settings → Pages**:
   - **Build and deployment**: Source = `Deploy from a branch`
   - Branch = `main` (ou `master`) / dossier = `/ (root)`
4. Attendez quelques instants puis ouvrez l’URL fournie par GitHub Pages : `https://<votre-utilisateur>.github.io/nfl-survivor/`

> Les données sont stockées **localement** dans le navigateur (LocalStorage). Le bouton *Exporter* vous permet de sauvegarder un fichier `.json` et *Importer* de recharger votre pool sur un autre appareil.

## Utiliser votre **nom de domaine** (optionnel)

1. Dans **Settings → Pages**, section **Custom domain**, entrez votre domaine, ex.: `survivor.votredomaine.com`. Cela crée un enregistrement **CNAME** côté GitHub.
2. Chez votre registraire (où vous gérez le DNS), ajoutez un enregistrement **CNAME**:
   - **Host**: `survivor` (ou la racine si vous voulez le domaine nu, voir ci‑dessous)
   - **Value**: `<votre-utilisateur>.github.io`
   - **TTL**: Auto / 1h
3. Pour le **domaine nu** (ex.: `votredomaine.com`), configurez des enregistrements **A** pointant vers les IPs GitHub Pages (si votre registraire ne supporte pas ALIAS/ANAME):
   - 185.199.108.153
   - 185.199.109.153
   - 185.199.110.153
   - 185.199.111.153
4. Retournez dans GitHub → **Settings → Pages** et cochez **Enforce HTTPS** dès que disponible.

## Personnaliser

- Ouvrez `index.html` et modifiez la constante `DEFAULT_PLAYERS` si besoin.
- Vous pouvez aussi changer le nombre de semaines (constante `WEEKS`) et les logos/équipes si nécessaire.

---

Fait pour **Gabriel, Étienne et Benoit**. Bon pool! 🏈